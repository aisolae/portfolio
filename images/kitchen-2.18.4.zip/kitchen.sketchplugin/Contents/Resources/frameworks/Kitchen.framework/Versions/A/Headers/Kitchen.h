//
//  KitchenFramework.h
//  KitchenFramework
//
//  Created by gaofeng.gf on 2017/10/16.
//  Copyright © 2017年 gaofeng.gf. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for KitchenFramework.
FOUNDATION_EXPORT double KitchenVersionNumber;

//! Project version string for KitchenFramework.
FOUNDATION_EXPORT const unsigned char KitchenVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KitchenFramework/PublicHeader.h>


